class cashier extends employee
{
	String jd="CASHIER";

	cashier(){}

	cashier(double sal)
	{
		super(sal);
	}
}