class clerk extends employee
{
	String jd="CLERK";
	 clerk(){}
	 clerk(double sal)
	{
		 super(sal);
	}
}