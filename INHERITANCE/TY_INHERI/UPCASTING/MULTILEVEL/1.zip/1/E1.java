class E1
{
	public static void main(String[]args)
	{
		//possible
		Account a1=new Account();
		loan_acc l1=new loan_acc();
		home_loan h1=new home_loan();
		car_loan c1=new car_loan();
		System.out.println(a1);
		System.out.println(l1);
		System.out.println(h1);
		System.out.println(c1);
	}
}