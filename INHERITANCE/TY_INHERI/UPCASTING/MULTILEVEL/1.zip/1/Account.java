class Account
{
	static int i=3;
	int j=33;

	static void acc()
	{
		System.out.println("static from Account");
	}

	void account()
	{
		System.out.println("non static from Account");
	}

}