class E5
{
	public static void main(String[]args)
	{
		//not possible
		home_loan h1=null;
		car_loan c1=h1;
		car_loan c2=new home_loan();
	}

}