class E2
{
	public static void main(String[]args)
	{
		//possible
		Account a1,a2,a3,a4;
		a1=new loan_acc();
		a2=new home_loan();
		a3=new car_loan();
		a4=null;
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
	}
}