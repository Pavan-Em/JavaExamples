class Employee
{
	static int i=3;
	int j=33;

	static void emp()
	{
		System.out.println("static from Employee");
	}

	void employee()
	{
		System.out.println("non static from Employee");
	}
}