class E1
{
	public static void main(String[]args)
	{
		//possible 
		Employee e1=new Employee();
		testing t1=new testing();
		development d1=new development();
		hr h1=new hr();
		automation_engg a1=new automation_engg();
		senior_dev s1=new senior_dev();
		recruiter r1=new recruiter();
	}
}