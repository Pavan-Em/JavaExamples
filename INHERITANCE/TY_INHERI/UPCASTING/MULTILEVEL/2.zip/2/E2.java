class E2
{
	public static void main(String[]args)
	{
		//possible
		Employee e1=new Employee();
		Employee e2=new testing();
		Employee e3=new development();
		Employee e4=new hr();
		Employee e5=new automation_engg();
		Employee e6=new senior_dev();
		Employee e7=new recruiter();
		Employee e8=null;
	}
}