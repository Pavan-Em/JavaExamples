class automation_engg extends testing
{
	static int m=5;
	int n=88;

	static void atomation()
	{
		System.out.println("static from atomation engg");
	}

	void engg()
	{
		System.out.println("non static from atomation engg");
	}
}