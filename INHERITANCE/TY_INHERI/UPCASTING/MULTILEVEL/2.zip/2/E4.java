class E4
{
	public static void main(String[]args)
	{
		//not possible
		hr h1=null;
		developmwnt d1=h1;
		testing t1=new development();
		automation_engg a1=new recruiter();
		senior_dev s1=new senior_dev();
		recruiter r1=s1;
		Employee e1=r1;//this is possible
	}
}