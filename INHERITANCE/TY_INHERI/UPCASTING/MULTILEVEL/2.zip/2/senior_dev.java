class senior_dev extends development
{
	static int o=6;
	int z=44;

	static void senior()
	{
		System.out.println("static from senior dev");
	}

	void develop()
	{
		System.out.println("non static from senior dev");
	}
}