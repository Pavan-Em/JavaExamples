class hr extends Employee
{
	static int x=4;
	int y=55;

	static void h()
	{
		System.out.println("static from hr");
	}

	void hr()
	{
		System.out.println("non static from hr");
	}
}