package emp.te;
import emp.employee;

public class te extends employee
{
	public String jd="TEST ENGG";
	public te(){}
	public te(String ename)
	{
		super(ename);
	}
}