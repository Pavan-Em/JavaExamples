package emp.dev;
import emp.employee;

public class dev extends employee
{
	public String jd="DEVELOPER";
	public dev (){}
	public dev (String ename)
	{
		super(ename);
	}
}